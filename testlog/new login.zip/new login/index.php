<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Inovbytez Registration Form</title>
    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
    
    <link rel="stylesheet" href="css/normalize.css">   
        <link rel="stylesheet" href="css/style.css">
  </head>
  
  <body>
  
    <div class="form" >
 
    
      
        <div id="signup">   
          <h1>Registration Form</h1>
          
          <form action="insert.php" method="post">
                 		  
						  
		<div class="field-wrap">
            <label>
              Invitation Code<span class="req">*</span>
            </label>
            <input name="i_code" type="text/css"required autocomplete="off"/>
          </div>
						  
						  
		  <div class="field-wrap">
            <label>
              Name<span class="req">*</span>
            </label>
            <input name="name" type="text/css"required autocomplete="off"/>
          </div>
		  
		  		  
		  
		  <div class="field-wrap">
            <label>
              Department Name<span class="req">*</span>
            </label>
            <input name="d_name" type="text/css"required autocomplete="off"/>
          </div>
	
	<div class="field-wrap">
            <label>
              Course<span class="req">*</span>
            </label>
            <input name="course" type="text/css"required autocomplete="off"/>
          </div>
	
	<div class="field-wrap">
            <label>
              Year<span class="req">*</span>
            </label>
            <input name="year" type="text/css"required autocomplete="off"/>
          </div>
		  
		  <div class="field-wrap">
            <label>
              Institution Name<span class="req">*</span>
            </label>
            <input name="in_name" type="text/css"required autocomplete="off"/>
          </div>
		  
		  <div class="field-wrap">
            <label>
              City Name<span class="req">*</span>
            </label>
            <input name="city_name" type="text/css"required autocomplete="off"/>
          </div>
		  
	
	
	<div class="container">
  
  <div class="dropdown">
    <span class="selLabel">Select Event 1</span>
    <input type="hidden" name="cd-dropdown">
    <ul class="dropdown-list">
      <li data-value="1">
        <span>Chalk Talk</span>
      </li>
      <li data-value="2">
        <span>Code Gush</span>
      </li>
      <li data-value="3">
        <span>Neuromaze</span>
      </li>
      <li data-value="4">
        <span>Ad-Hawk</span>
      </li>
	  <li data-value="5">
        <span>Reckless</span>
      </li>
	  <li data-value="6">
        <span>Crack ode</span>
      </li>
	  <li data-value="7">
        <span>Cyber Sketch</span>
      </li>
	  <li data-value="8">
        <span>Ace Hunt</span>
      </li>
	  <li data-value="9">
        <span>Aperture</span>
      </li>
    </ul>
	<br></br>
	
	<div class="dropdown1">
	<span class="selLabel1">Select Event 2</span>
    <input type="hidden" name="cd-dropdown1">
    <ul class="dropdown1-list">
      <li data-value="1">
        <span>Chalk Talk</span>
      </li>
      <li data-value="2">
        <span>Code Gush</span>
      </li>
      <li data-value="3">
        <span>Neuromaze</span>
      </li>
      <li data-value="4">
        <span>Ad-Hawk</span>
      </li>
	  <li data-value="5">
        <span>Reckless</span>
      </li>
	  <li data-value="6">
        <span>Crack ode</span>
      </li>
	  <li data-value="7">
        <span>Cyber Sketch</span>
      </li>
	  <li data-value="8">
        <span>Ace Hunt</span>
      </li>
	  <li data-value="9">
        <span>Aperture</span>
      </li>
    </ul>	
  </div> 
</div>	
	<br></br>
	<div class="field-wrap">
            <label>
              E-mail<span class="req">*</span>
            </label>
            <input name="email" type="email"required autocomplete="off"/>
          </div>
		  <div class="field-wrap">
		  <label>
              Mobile Number<span class="req">*</span>
            </label>
            <input name="m_num" type="text/css"required autocomplete="off"/>
          </div>

		  
		<div>
          <button type="submit" class="button button-block"/>Register</button>
          </form>
        </div>
      
</div> <!-- /form -->
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
